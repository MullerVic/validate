from fastapi import APIRouter, Depends, HTTPException, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.models.user import Usuario, CriaUsuario, RespostaUsuario, AtualizaUsuario
from app.config.database import get_db

router = APIRouter(prefix="/usuario", tags=["usuario"])

# Rota API: Criação via JSON (sem login automático)
@router.post("/", response_model=RespostaUsuario)
def cria_usuario(usuario: CriaUsuario, db: Session = Depends(get_db)):
    try:
        required_fields = ['nome', 'email', 'senha']
        for field in required_fields:
            if not hasattr(usuario, field):
                raise HTTPException(status_code=400, detail=f"Campo obrigatório faltando: {field}")

        db_usuario = Usuario(
            nome=usuario.nome,
            email=usuario.email,
            senha=usuario.senha,
            is_admin=usuario.is_admin
        )
        db.add(db_usuario)
        db.commit()
        db.refresh(db_usuario)

        return RespostaUsuario.model_validate(db_usuario)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao criar usuário: {str(e)}")


# Rota FORM: Cadastro ou login via formulário HTML com login automático
@router.post("/cadastrar_form")
def cadastrar_form_usuario(
    nome: str = Form(...),
    email: str = Form(...),
    senha: str = Form(...),
    db: Session = Depends(get_db)
):
    try:
        usuario_existente = db.query(Usuario).filter(Usuario.email == email).first()

        if usuario_existente:
            # Verifica senha
            if usuario_existente.senha != senha:
                raise HTTPException(status_code=400, detail="Senha incorreta para e-mail já cadastrado.")

            # Login automático
            response = RedirectResponse(url="/supermercados/busca_html", status_code=303)
            response.set_cookie(key="usuario_id", value=str(usuario_existente.id_usuario), httponly=True)
            return response

        # Criação de novo usuário
        novo_usuario = Usuario(
            nome=nome,
            email=email,
            senha=senha,
            is_admin=False
        )
        db.add(novo_usuario)
        db.commit()
        db.refresh(novo_usuario)

        # Login automático após cadastro
        response = RedirectResponse(url="/supermercados/busca_html", status_code=303)
        response.set_cookie(key="usuario_id", value=str(novo_usuario.id_usuario), httponly=True)
        return response

    except HTTPException as e:
        raise e
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Erro ao cadastrar ou logar usuário: {str(e)}")


# Rota: Ler usuário por ID
@router.get("/{id_usuario}", response_model=RespostaUsuario)
def ler_usuario(id_usuario: int, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.id_usuario == id_usuario).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    return usuario


# Rota: Atualizar usuário
@router.put("/{id_usuario}", response_model=RespostaUsuario)
def atualiza_usuario(id_usuario: int, data_usuario: AtualizaUsuario, db: Session = Depends(get_db)):
    db_usuario = db.query(Usuario).filter(Usuario.id_usuario == id_usuario).first()
    if not db_usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    db_usuario.nome = data_usuario.nome
    db_usuario.email = data_usuario.email
    db_usuario.senha = data_usuario.senha

    db.commit()
    db.refresh(db_usuario)

    return db_usuario


# Rota: Deletar usuário
@router.delete("/{id_usuario}")
def deleta_usuario(id_usuario: int, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.id_usuario == id_usuario).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    db.delete(usuario)
    db.commit()

    return {"message": "Usuário deletado com sucesso"}
