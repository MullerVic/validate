from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session, joinedload
from config.database import get_db
from datetime import date, timedelta
from models.product import Produto
import os

router = APIRouter(prefix="/produtos", tags=["Produtos Views"])
templates = Jinja2Templates(directory=os.path.abspath("/templates"))

@router.get("/", response_class=HTMLResponse)
async def exibir_produtos(request: Request, db: Session = Depends(get_db)):
  
  """
  Rota para exibir a lista de produtos em HTML
  """
  produtos = db.query(Produto).all()
  return templates.TemplateResponse("exibeProdutos.html", {
        "request": request,
        "produtos": produtos
    })
  
@router.get("/cadastro", response_class=HTMLResponse)
async def formulario_cadastro_produto(request: Request):
  """Rota para exibir o formulário de cadastro"""
  
  return templates.TemplateResponse(
    "cadastroProduto.html", 
    {"request": request}
  )