from fastapi import APIRouter, Depends, HTTPException, Form, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models.user import Usuario, CriaUsuario, RespostaUsuario, AtualizaUsuario
from app.config.database import get_db

router = APIRouter(prefix="/supermercados", tags=["supermercados"])
templates = Jinja2Templates(directory="app/templates")


# Dependência para obter usuário logado via cookie
def get_usuario_logado(request: Request, db: Session = Depends(get_db)):
    usuario_id = request.cookies.get("usuario_id")
    if usuario_id:
        return db.query(Usuario).filter(Usuario.id_usuario == int(usuario_id)).first()
    return None


# Rota: Página HTML para exibir supermercados fictícios (apresentação)
@router.get("/busca_html", response_class=HTMLResponse)
def exibe_supermercados(request: Request):
    # Supermercados fictícios
    supermercados = [
        {
            "nome_supermercado": "SuperMais",
            "endereco": "Rua das Flores, 123",
            "raio_entrega_km": 5,
            "img": "/static/img/supermais.jpg"
        },
        {
            "nome_supermercado": "SuperMarket",
            "endereco": "Av. Central, 456",
            "raio_entrega_km": 8,
            "img": "/static/img/supermarket.jpg"
        },
        {
            "nome_supermercado": "Family",
            "endereco": "Travessa Norte, 789",
            "raio_entrega_km": 10,
            "img": "/static/img/family.jpg"
        }
    ]

    return templates.TemplateResponse("exibeSupermercados.html", {
        "request": request,
        "supermercados": supermercados
    })


# Rota API: Criação de usuário via JSON
@router.post("/", response_model=RespostaUsuario)
def cria_usuario(usuario: CriaUsuario, db: Session = Depends(get_db)):
    try:
        required_fields = ['nome', 'email', 'senha']
        for field in required_fields:
            if not hasattr(usuario, field):
                raise HTTPException(status_code=400, detail=f"Campo obrigatório faltando: {field}")

        db_usuario = Usuario(
            nome=usuario.nome,
            email=usuario.email,
            senha=usuario.senha,
            is_admin=usuario.is_admin
        )
        db.add(db_usuario)
        db.commit()
        db.refresh(db_usuario)

        return RespostaUsuario.model_validate(db_usuario)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao criar usuário: {str(e)}")


# Leitura, atualização e deleção de usuário
@router.get("/{id_usuario}", response_model=RespostaUsuario)
def ler_usuario(id_usuario: int, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.id_usuario == id_usuario).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    return usuario


@router.put("/{id_usuario}", response_model=RespostaUsuario)
def atualiza_usuario(id_usuario: int, data_usuario: AtualizaUsuario, db: Session = Depends(get_db)):
    db_usuario = db.query(Usuario).filter(Usuario.id_usuario == id_usuario).first()
    if not db_usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    db_usuario.nome = data_usuario.nome
    db_usuario.email = data_usuario.email
    db_usuario.senha = data_usuario.senha

    db.commit()
    db.refresh(db_usuario)

    return db_usuario


@router.delete("/{id_usuario}")
def deleta_usuario(id_usuario: int, db: Session = Depends(get_db)):
    usuario = db.query(Usuario).filter(Usuario.id_usuario == id_usuario).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    db.delete(usuario)
    db.commit()

    return {"message": "Usuário deletado com sucesso"}
