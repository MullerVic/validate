from fastapi import Request, FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.models.product import Produto
from app.models.user import Usuario
from app.models.supermercado import Supermercado
from app.config.database import engine, Base
from app.routes.products import router as rotas_produtos
from app.routes.users import router as rotas_usuarios
from app.routes.supermercado import router as rotas_supermercado
from app.routes.produtos_view import router as rotas_view_produtos
from dotenv import load_dotenv

load_dotenv()

# Cria as tabelas no banco
Base.metadata.create_all(engine)

app = FastAPI()

app.mount("/static", StaticFiles(directory="app/static"), name="static")

templates = Jinja2Templates(directory="app/templates")

app.include_router(rotas_view_produtos)
app.include_router(rotas_produtos)
app.include_router(rotas_usuarios)
app.include_router(rotas_supermercado)

@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("cadastroUsuario.html", {"request": request})
