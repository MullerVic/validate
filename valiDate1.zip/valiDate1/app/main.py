from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from models.product import Produto
from models.user import Usuario
from models.supermercado import Supermercado
from config.database import engine,Base
from routes.products import router as rotas_produtos
from routes.users import router as rotas_usuarios
from routes.supermercado import router as rotas_supermercado
from routes.produtos_view import router as rotas_view_produtos
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

app.mount("/static", StaticFiles(directory="/static"), name="static")

templates = Jinja2Templates(directory="templates")

app.include_router(rotas_view_produtos)
app.include_router(rotas_produtos)
app.include_router(rotas_usuarios)
app.include_router(rotas_supermercado)

@app.get("/")
def read_root():
  return {"mensagem": "API de produtos próximos à validade"}

#Base.metadata.drop_all(engine)
Base.metadata.create_all(engine)